..
  Directives documentation:
  https://www.sphinx-doc.org/en/master/usage/restructuredtext/directives.html

qpdf version |release|
======================

..
  Include the actual text of the link to readthedocs so it shows up in
  the PDF when printed.

Welcome to the qpdf documentation! For the latest version of this
documentation, please visit `https://qpdf.readthedocs.io
<https://qpdf.readthedocs.io>`__.

..
  **REMEMBER** -- update CMakeLists.txt when new files are added.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   license
   download
   installation
   packaging
   cli
   qdf
   library
   weak-crypto
   json
   contributing
   design
   qpdf-job
   linearization
   object-streams
   encryption
   release-notes
   acknowledgement

.. toctree::
   :maxdepth: 1
   :caption: Appendices:

   inspection

Indices
=======

* :ref:`qpdf-options`
